# Cagalidinhos Edits Pro AI (2.5 starter)

Local web app + FastAPI backend + FFmpeg render engine.

## Implemented features
- Upload multiple videos and optional music; render final MP4 with preview and download.
- Semantic Vision AI: sample frames from uploaded clips and ask a vision model to identify moments relevant to the user's edit request. Requires a valid API key and internet connection. This analyzes sampled frames; it is not guaranteed to recognize every exact event correctly.
- Fallback scene/activity-based selection if semantic vision is disabled or unavailable.
- Clip Hunter search: returns video search results and links via yt-dlp. It does not download third-party videos. Use clips you own, upload, or have permission to use.
- Music analysis with optional librosa to estimate BPM and beat positions.
- Cut-duration snapping to approximate beat intervals, plus video effects (shake, slow motion, flash, zoom, dark grade).
- Formats: vertical 9:16, widescreen 16:9, square 1:1; 720p/1080p settings.

## Important limits
- Search returns links/results; it does not identify the exact requested moment inside online source videos or auto-download those videos. Upload the clips you want the AI to analyze.
- Semantic video understanding is frame-sampled and model-assisted. It may miss moments between samples and can be wrong. It is not an autonomous sports broadcast archive search engine.
- Beat analysis needs librosa and supported audio; render syncing approximates cut lengths to beat duration, not a full musical arrangement editor.
- This is not hosted online. Run it on a PC/server with Python and FFmpeg.
- API costs are separate from ChatGPT subscriptions. Use your own API key securely; never put it in frontend code or share it.

## Windows quick start
1. Extract the ZIP.
2. Install Python 3.10+ and FFmpeg, and ensure `ffmpeg` and `ffprobe` are available in PATH.
3. Open `backend` and run `start_windows.bat`. It creates a virtual environment, installs packages, and starts the web server.
4. Edit `backend/.env` and add a NEW key: `OPENAI_API_KEY=...`. (If you have exposed a key, revoke it first and create a replacement.)
5. Open http://localhost:8000 in your browser.

## Test API
After creating `.env` with a valid key, from backend folder run:
`python test_openai_vision.py`
This performs a real text API connection check. To test image input using a video frame, install `opencv-python` and run:
`python test_openai_vision.py path/to/video.mp4`

## API endpoints
- `GET /health`
- `POST /clip-search` (query form)
- `POST /analyze-audio` (audio upload)
- `POST /vision-test` (image upload)
- `POST /render` (video uploads + optional audio)
- `GET /preview/{job_id}` and `GET /download/{job_id}`
