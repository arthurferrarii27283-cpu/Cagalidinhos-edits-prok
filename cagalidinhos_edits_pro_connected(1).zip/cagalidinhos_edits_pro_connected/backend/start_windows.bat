@echo off
cd /d %~dp0
if not exist .venv python -m venv .venv
call .venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
if not exist .env copy .env.example .env
echo.
echo Configure backend\.env with your NEW API key if you want semantic vision.
echo Starting Cagalidinhos Edits Pro at http://127.0.0.1:8000
python -m uvicorn main:app --host 0.0.0.0 --port 8000
pause
