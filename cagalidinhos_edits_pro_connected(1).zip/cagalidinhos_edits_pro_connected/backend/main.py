import os, uuid, json, shutil, subprocess, tempfile, math
from pathlib import Path
from typing import List, Optional
from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.responses import HTMLResponse, FileResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from dotenv import load_dotenv

BASE = Path(__file__).resolve().parent
WORK = BASE / 'work'; OUTPUTS = BASE / 'outputs'
WORK.mkdir(exist_ok=True); OUTPUTS.mkdir(exist_ok=True)
load_dotenv(BASE / '.env')
API_KEY = os.getenv('OPENAI_API_KEY','').strip()
VISION_MODEL = os.getenv('SEMANTIC_MODEL','gpt-4o-mini')
app = FastAPI(title='Cagalidinhos Edits Pro AI', version='2.5')
app.add_middleware(CORSMiddleware, allow_origins=['*'], allow_methods=['*'], allow_headers=['*'])

def ffmpeg_ok():
    return shutil.which('ffmpeg')

def run(cmd):
    p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if p.returncode != 0:
        raise RuntimeError((p.stderr or 'FFmpeg failed')[-2500:])
    return p

def duration(path):
    cmd = ['ffprobe','-v','error','-show_entries','format=duration','-of','default=noprint_wrappers=1:nokey=1',str(path)]
    p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    try: return float(p.stdout.strip())
    except: return 0.0

def extract_frames(path, every=2.0, limit=36):
    d = duration(path); ts=[]
    if d <= 0: return ts
    t=0.0
    n=0
    while t < d and n < limit:
        out = WORK / f'frame_{uuid.uuid4().hex}.jpg'
        run(['ffmpeg','-y','-ss',str(t),'-i',str(path),'-frames:v','1','-vf','scale=640:-1','-q:v','4',str(out)])
        if out.exists() and out.stat().st_size:
            ts.append((t,out)); n+=1
        t += every
    return ts

def semantic_analyze_video(path, request):
    """Analyze sampled frames. Requires OPENAI_API_KEY; never fetches video from web."""
    if not API_KEY:
        return {'available':False,'error':'OPENAI_API_KEY not configured','moments':[]}
    frames = extract_frames(path, every=max(1.5, duration(path)/18), limit=18)
    if not frames: return {'available':False,'error':'Could not extract video frames','moments':[]}
    try:
        from openai import OpenAI
        client=OpenAI(api_key=API_KEY)
        # Send thumbnails with timestamps; model identifies relevant actions and moments.
        content=[{'type':'text','text':f"Analyze these sequential frames from a video. User edit request: {request!r}. Video duration: {duration(path):.2f} seconds. Frame timestamps in seconds are shown before each image. Identify the strongest relevant moments for the requested edit. Return ONLY JSON with schema {{'moments':[{{'time':number,'score':1-10,'event':'short description','reason':'why this is a strong moment'}}]}}. Only choose moments supported by the frames; do not invent a goal/dribble/event if not visible."}]
        for ts,fp in frames:
            import base64
            b64=base64.b64encode(fp.read_bytes()).decode()
            content.append({'type':'text','text':f'Frame at {ts:.2f} seconds'})
            content.append({'type':'image_url','image_url':{'url':f'data:image/jpeg;base64,{b64}','detail':'low'}})
        response=client.chat.completions.create(model=VISION_MODEL, messages=[{'role':'user','content':content}], temperature=0.2, max_tokens=900)
        raw=response.choices[0].message.content or '{}'
        raw=raw.replace('```json','').replace('```','').strip()
        data=json.loads(raw)
        moments=data.get('moments',[])
        # Clamp/normalize and remove duplicates, sorted by score.
        clean=[]; seen=set()
        for m in moments:
            t=max(0,min(duration(path),float(m.get('time',0))))
            key=round(t)
            if key in seen: continue
            seen.add(key); clean.append({'time':t,'score':max(1,min(10,int(m.get('score',5)))),'event':str(m.get('event','Moment'))[:180],'reason':str(m.get('reason',''))[:300]})
        return {'available':True,'model':VISION_MODEL,'moments':sorted(clean,key=lambda x:x['score'],reverse=True)[:10]}
    except Exception as e:
        return {'available':False,'error':f'Vision analysis failed: {str(e)[:350]}','moments':[]}
    finally:
        for _,fp in frames:
            try: fp.unlink()
            except: pass

def audio_analyze(path):
    """Beat/BPM analysis with librosa. Graceful fallback when optional package is absent."""
    try:
        import librosa
        y,sr=librosa.load(str(path),sr=None,mono=True)
        tempo, beat_frames=librosa.beat.beat_track(y=y,sr=sr,units='frames')
        beats=librosa.frames_to_time(beat_frames,sr=sr).tolist()
        onset_frames=librosa.onset.onset_detect(y=y,sr=sr,backtrack=False)
        onsets=librosa.frames_to_time(onset_frames,sr=sr).tolist()
        return {'available':True,'bpm':float(tempo[0] if hasattr(tempo,'__len__') else tempo),'beats':beats[:600],'onsets':onsets[:600],'duration':duration(path)}
    except Exception as e:
        return {'available':False,'error':str(e)[:300],'bpm':None,'beats':[],'onsets':[],'duration':duration(path)}

def visual_activity_scores(path, sample_seconds=1.0):
    """Fallback heuristic: frame-to-frame image differences via ffmpeg scene score metadata."""
    d=duration(path); scored=[]
    # Scene change detector output at 0.5 threshold
    try:
        p=subprocess.run(['ffmpeg','-i',str(path),'-vf',r'select=gt(scene\,0.20),showinfo','-vsync','vfr','-f','null','-'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
        import re
        for m in re.finditer(r'pts_time:([0-9.]+)',p.stderr):
            scored.append({'time':float(m.group(1)),'score':5,'event':'Scene/activity change','reason':'Visual scene-change heuristic (not semantic recognition)'})
    except: pass
    if not scored and d: scored=[{'time':min(d/2,1.0),'score':3,'event':'Middle of clip','reason':'Fallback selection; semantic API is unavailable'}]
    return scored

def nearest_beat(t, beats):
    if not beats: return t
    return min(beats,key=lambda b:abs(b-t))

def make_segments(videos, semantic_results, target_seconds, beats, bpm=None):
    candidates=[]
    for idx,vid in enumerate(videos):
        d=duration(vid)
        moments=semantic_results[idx].get('moments') if idx<len(semantic_results) and semantic_results[idx].get('available') else None
        if not moments: moments=visual_activity_scores(vid)
        for m in moments:
            t=float(m.get('time',d/2)); score=float(m.get('score',4))
            # Start ~2.5 sec before identified timestamp, with a short cap to clip bounds.
            start=max(0,t-2.3); end=min(d,start+4.2)
            if end-start<0.7: continue
            candidates.append({'file':vid,'start':start,'end':end,'score':score,'event':m.get('event','moment'),'reason':m.get('reason','')})
    candidates.sort(key=lambda c:c['score'],reverse=True)
    if not candidates:
        for v in videos:
            d=duration(v); candidates.append({'file':v,'start':0,'end':min(d,4.5),'score':1,'event':'clip segment','reason':'Fallback'})
    selected=[]; remaining=max(2.0,target_seconds)
    # Take high scores, then chronologically across clips as much as possible.
    for c in candidates:
        segdur=min(c['end']-c['start'],remaining)
        if segdur<0.5: continue
        c={**c,'end':c['start']+segdur}; selected.append(c); remaining-=segdur
        if remaining<=0: break
    # Sync segment lengths to beat interval when beat grid exists, but preserve final target.
    if beats and len(selected)>1:
        interval=60.0/max(1.0,float(bpm or 120.0))
        for i,c in enumerate(selected[:-1]):
            current=c['end']-c['start']; snapped=max(0.7,round(current/interval)*interval)
            c['end']=min(duration(c['file']),c['start']+snapped)
    return selected

def render_job(jobdir, videos, music, request, aspect, quality, seconds, effect, use_semantic):
    if effect=='auto':
        q=request.lower()
        if any(k in q for k in ['shake','tremor','impact']): effect='shake'
        elif any(k in q for k in ['slow','slow motion','câmera lenta']): effect='slow'
        elif 'flash' in q: effect='flash'
        elif 'zoom' in q: effect='zoom'
        elif any(k in q for k in ['dark','escuro','dark aura']): effect='dark'
        else: effect='none'
    width,height={'9:16':(720,1280),'16:9':(1280,720),'1:1':(1080,1080)}.get(aspect,(720,1280))
    if quality=='1080p':
        width,height={'9:16':(1080,1920),'16:9':(1920,1080),'1:1':(1080,1080)}.get(aspect,(1080,1920))
    sem=[]
    if use_semantic:
        for v in videos: sem.append(semantic_analyze_video(v,request))
    else: sem=[{'available':False,'moments':[]} for _ in videos]
    audio=None
    if music:
        audio=audio_analyze(music)
    beats=audio.get('beats',[]) if audio else []
    segments=make_segments(videos,sem,seconds,beats,audio.get('bpm') if audio else None)
    if not segments: raise RuntimeError('No usable segments were found.')
    pieces=[]
    for i,s in enumerate(segments):
        piece=jobdir/f'segment_{i:03d}.mp4'; pieces.append(piece)
        # Normalize video, remove original audio; effects on all selected segments.
        vf=f"scale={width}:{height}:force_original_aspect_ratio=increase,crop={width}:{height},fps=30,setsar=1"
        if effect=='shake': vf+=f",scale={width*1.08}:{height*1.08},crop={width}:{height}:x=\'(iw-ow)/2+8*sin(30*t)\':y=\'(ih-oh)/2+8*cos(30*t)\'"
        elif effect=='slow': vf+=",setpts=1.25*PTS"
        elif effect=='dark': vf+=",eq=brightness=-0.06:contrast=1.15:saturation=1.15"
        elif effect=='flash': vf+=",eq=brightness=0.10:contrast=1.05"
        elif effect=='zoom': vf+=",zoompan=z='min(zoom+0.0015,1.12)':d=1:s=%dx%d"%(width,height)
        run(['ffmpeg','-y','-ss',f"{s['start']:.3f}",'-i','x']) if False else None
        cmd=['ffmpeg','-y','-ss',f"{s['start']:.3f}",'-i',str(s['file']),'-t',f"{max(.5,s['end']-s['start']):.3f}",'-vf',vf,'-an','-c:v','libx264','-preset','veryfast','-crf','23','-pix_fmt','yuv420p',str(piece)]
        run(cmd)
    concat=jobdir/'concat.txt'; concat.write_text(''.join(f"file '{p.resolve().as_posix()}'\n" for p in pieces),encoding='utf8')
    output=jobdir/'final.mp4'
    cmd=['ffmpeg','-y','-f','concat','-safe','0','-i',str(concat)]
    if music: cmd+=['-i',str(music)]
    cmd+=['-c:v','libx264','-preset','veryfast','-crf','22','-pix_fmt','yuv420p']
    if music: cmd+=['-map','0:v:0','-map','1:a:0','-shortest','-c:a','aac','-b:a','192k']
    else: cmd+=['-an']
    cmd+=['-movflags','+faststart',str(output)]
    run(cmd)
    return output,sem,audio,segments

@app.get('/health')
def health():
    return {'ok':True,'ffmpeg':bool(ffmpeg_ok()),'api_key_configured':bool(API_KEY),'vision_model':VISION_MODEL,'audio_analyzer':'librosa optional'}

@app.get('/',response_class=HTMLResponse)
def home():
    html=(BASE.parent/'frontend'/'index.html')
    return HTMLResponse(html.read_text(encoding='utf8'))

@app.post('/clip-search')
def clip_search(query:str=Form(...), limit:int=Form(8)):
    try:
        import yt_dlp
        opts={'quiet':True,'skip_download':True,'extract_flat':'in_playlist','no_warnings':True}
        with yt_dlp.YoutubeDL(opts) as ydl:
            info=ydl.extract_info(f'ytsearch{max(1,min(limit,15))}:{query}',download=False)
        entries=info.get('entries',[]) if info else []
        results=[]
        for e in entries:
            if not e: continue
            url=e.get('url') or e.get('webpage_url') or (f"https://www.youtube.com/watch?v={e.get('id')}" if e.get('id') else '')
            results.append({'title':e.get('title','Untitled'),'url':url,'channel':e.get('channel') or e.get('uploader'),'duration':e.get('duration'),'thumbnail':e.get('thumbnail')})
        return {'results':results,'note':'Search results only. This app does not automatically download third-party clips.'}
    except Exception as e: return {'results':[],'error':str(e)[:350],'note':'Clip search is unavailable. Install dependencies and ensure internet access.'}

@app.post('/analyze-audio')
async def analyze_audio(file:UploadFile=File(...)):
    ext=Path(file.filename or 'audio.mp3').suffix or '.mp3'; p=WORK/f'{uuid.uuid4().hex}{ext}'
    p.write_bytes(await file.read())
    try: return audio_analyze(p)
    finally:
        try:p.unlink()
        except:pass

@app.post('/render')
async def render(files:List[UploadFile]=File(...),music:Optional[UploadFile]=File(None),request:str=Form(''),clip_mode:str=Form('uploaded'),aspect:str=Form('9:16'),quality:str=Form('720p'),duration_seconds:int=Form(20),effect:str=Form('none'),semantic:bool=Form(True)):
    if not ffmpeg_ok(): raise HTTPException(500,'FFmpeg is not installed or is not in PATH.')
    if not files: raise HTTPException(400,'Upload at least one video clip.')
    job_id=uuid.uuid4().hex; jobdir=WORK/job_id; jobdir.mkdir()
    videos=[]
    for f in files:
        ext=Path(f.filename or 'video.mp4').suffix.lower()
        if ext not in ['.mp4','.mov','.mkv','.webm','.m4v','.avi']: continue
        p=jobdir/f'{uuid.uuid4().hex}{ext}'; p.write_bytes(await f.read()); videos.append(p)
    if not videos: raise HTTPException(400,'No supported video files were uploaded.')
    mp=None
    if music and music.filename:
        ext=Path(music.filename).suffix or '.mp3'; mp=jobdir/f'music{ext}'; mp.write_bytes(await music.read())
    try:
        output,sem,audio,segs=render_job(jobdir,videos,mp,request,aspect,quality,max(5,min(duration_seconds,120)),effect,semantic)
        # Keep results inside job directory, link through ID.
        return {'status':'completed','job_id':job_id,'preview_url':f'/preview/{job_id}','download_url':f'/download/{job_id}','semantic':sem,'music_analysis':audio,'selected_segments':[{'start':s['start'],'end':s['end'],'score':s['score'],'event':s['event'],'reason':s['reason']} for s in segs],'message':'Rendered video ready. Semantic selection is used where API is configured; otherwise heuristic fallback is used.'}
    except Exception as e: raise HTTPException(500,f'Render failed: {str(e)[:700]}')

@app.get('/preview/{job_id}')
def preview(job_id:str):
    p=WORK/job_id/'final.mp4'
    if not p.exists(): raise HTTPException(404,'Video not found')
    return FileResponse(p,media_type='video/mp4')
@app.get('/download/{job_id}')
def download(job_id:str):
    p=WORK/job_id/'final.mp4'
    if not p.exists(): raise HTTPException(404,'Video not found')
    return FileResponse(p,media_type='video/mp4',filename='cagalidinhos_edit.mp4')

@app.post('/vision-test')
async def vision_test(image_file:UploadFile=File(...),prompt:str=Form('Describe the action in this image and whether it contains a football highlight.')):
    if not API_KEY: return {'ok':False,'error':'API key not configured in backend/.env'}
    try:
        from openai import OpenAI
        import base64
        raw=await image_file.read(); b64=base64.b64encode(raw).decode()
        client=OpenAI(api_key=API_KEY)
        r=client.chat.completions.create(model=VISION_MODEL,messages=[{'role':'user','content':[{'type':'text','text':prompt},{'type':'image_url','image_url':{'url':f'data:{image_file.content_type or "image/jpeg"};base64,{b64}'}}]}],max_tokens=500)
        return {'ok':True,'model':VISION_MODEL,'result':r.choices[0].message.content}
    except Exception as e:return {'ok':False,'error':str(e)[:600]}
