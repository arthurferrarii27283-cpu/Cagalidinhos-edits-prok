#!/usr/bin/env bash
cd "$(dirname "$0")"
python3 -m venv .venv
source .venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
[ -f .env ] || cp .env.example .env
printf '\nConfigure backend/.env with a NEW API key for semantic vision.\n'
python -m uvicorn main:app --host 0.0.0.0 --port 8000
