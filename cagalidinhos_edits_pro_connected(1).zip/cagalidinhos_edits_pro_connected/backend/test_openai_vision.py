import os, sys, base64, subprocess, tempfile
from pathlib import Path
from dotenv import load_dotenv
load_dotenv(Path(__file__).parent / '.env')
key=os.getenv('OPENAI_API_KEY','').strip()
if not key:
 print('API key missing. Add OPENAI_API_KEY to backend/.env.');sys.exit(2)
model=os.getenv('SEMANTIC_MODEL','gpt-4o-mini')
try:
 from openai import OpenAI
 client=OpenAI(api_key=key)
 # Authentication/model access test (real API call)
 r=client.chat.completions.create(model=model,messages=[{'role':'user','content':'Reply with exactly: API CONNECTION OK'}],max_tokens=12)
 print('Text API connection:',r.choices[0].message.content)
 if len(sys.argv)>1:
  source=Path(sys.argv[1]).expanduser().resolve()
  suffix=source.suffix.lower()
  if suffix in {'.jpg','.jpeg','.png','.webp'}:
   image_bytes=source.read_bytes();mime={'.jpg':'image/jpeg','.jpeg':'image/jpeg','.png':'image/png','.webp':'image/webp'}.get(suffix,'image/jpeg')
  else:
   # FFmpeg extracts one real frame from a supplied video without OpenCV.
   with tempfile.NamedTemporaryFile(suffix='.jpg',delete=False) as temp:
    frame=Path(temp.name)
   subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-ss','1','-i',str(source),'-frames:v','1','-vf','scale=640:-1',str(frame)],check=True)
   image_bytes=frame.read_bytes();mime='image/jpeg';frame.unlink(missing_ok=True)
  data=base64.b64encode(image_bytes).decode()
  resp=client.chat.completions.create(model=model,messages=[{'role':'user','content':[{'type':'text','text':'Describe what is visibly happening in this image in one sentence. Do not infer events that are not shown.'},{'type':'image_url','image_url':{'url':f'data:{mime};base64,{data}','detail':'low'}}]}],max_tokens=100)
  print('Vision response:',resp.choices[0].message.content)
 else:
  print('For an image/video vision test, add a file path, for example: python test_openai_vision.py ../clip.mp4')
 print('API test completed. This verifies API access and image input; it does not certify sports event recognition accuracy.')
except Exception as e:
 print('API test failed:',str(e));sys.exit(1)
